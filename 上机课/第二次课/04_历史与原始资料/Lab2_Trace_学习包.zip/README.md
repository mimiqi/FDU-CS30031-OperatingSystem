# Lab2 模块实践指导

本学习包对应第二次课的 `Lab_systemcalls_traps.pptx`。按你的要求，每次只推进一个模块：先理解需求，再修改代码，最后在 VMware 中的 Ubuntu 24 完成编译、测试和记录。

Windows 用于保存和传递这些文档、补丁与参考源码。以下涉及依赖安装、xv6 编译、QEMU 和验收的命令，都在 VMware 的 Ubuntu 24 终端执行。

## 当前模块

本次交付 **Trace** 的完整技术指导、参考补丁和八份修改后的源文件。参考代码以 MIT 官方 `xv6-labs-2024` 的 `syscall` 分支为基线。

- [Trace 技术指导](01_Trace/技术指导.md)：从环境检查到逐文件实现。
- [参考代码说明](01_Trace/参考代码说明.md)：补丁的使用方法和版本限制。
- [实践记录](01_Trace/实践记录.md)：测试与报告的填写模板。
- `01_Trace/参考代码/trace.patch`：可在匹配的实验分支上应用的补丁。
- `01_Trace/参考代码/修改后文件/`：八份完整源文件，用于逐行对照。

这份材料已完成源码接口核对与补丁适用性检查。**尚未在你的 Ubuntu 24 虚拟机上编译和运行，测试结果需要你实际执行后填写。**

## 后续模块

Trace 实践完成后，继续推进剩余模块：

1. Attack xv6：理解实验中故意保留的物理页数据和进程隔离问题。
2. RISC-V 问答：分析自己编译出来的 `user/call.asm`。
3. Backtrace：沿内核栈帧输出返回地址。
4. Alarm：实现周期性用户处理函数与现场恢复。

这些模块目前尚未生成参考实现，也未完成测试。System calls 与 Traps 最终仍按课件要求分开整理报告和代码。

## 版本提醒

第一次上机报告中使用的是新版 `mit-pdos/xv6-riscv`，其中用户接口已经出现 `pause()`。这次课件使用的是 `xv6-labs-2024` 实验仓库，其中存在 `syscall` 和 `traps` 分支，并使用 `sleep()`。

两个仓库的代码不能直接混用。请保留第一次实验的原目录，第二次实验另建 `~/os/xv6-labs-2024`。Windows 课程资料仓库与 Ubuntu 中的 xv6 实验仓库也是两个不同的仓库。

## 资料依据

- 本地课件：`上机课/第二次课/Lab_systemcalls_traps.pptx`，Trace 对应第 12 至 17 页。
- [MIT System calls 实验说明](https://pdos.csail.mit.edu/6.1810/2024/labs/syscall.html)。课程任务与提交要求以老师的 PPT 为准。
- [MIT 实验工具说明](https://pdos.csail.mit.edu/6.1810/2024/tools.html)。
- 官方源码：`git://g.csail.mit.edu/xv6-labs-2024`。

本学习包仅保存到本地课程目录，尚未提交或推送到远端。
